void setup() {
  volatile char*dira=0x21;
  volatile char*dirb=0x24;
  *dira=0x07;*dirb=0x00;
  timer1();
  timer2();
}
long x;
long y;
long sec1=1;
long sec2=1;
void bounce(){
  volatile long i;
  for(i=0;i<100000;i++);
}
void loop() {
  long a,b,c,d;
  volatile long i;
  volatile char*inb=0x23;
  while(*inb==0x01){
    bounce();
    a=*inb;
    bounce();
    while(a==0x01){
      b=*inb;
      bounce();
      while(b==0x01){
        c=*inb;
        bounce();
        while(c==0x01){
          d=*inb;
          bounce();
          while(d==*inb){
            sec1=2;
            sec2=2;
          }
        }
      }
    }
  }
}
void timer1(){
  volatile char*tccr1a=0x80;
  volatile char*tccr1b=0x81;
  volatile char*tcnt1l=0x84;
  volatile char*tcnt1h=0x85;
  volatile char*ocr1al=0x88;
  volatile char*ocr1ah=0x89;
  volatile char*timsk1=0x6F;
  *tccr1a=0x00;
  *tccr1b=0x0D;
  *tcnt1h=0x00;
  *tcnt1l=0x00;
  *ocr1ah=0x3D;
  *ocr1al=0x08;
  *timsk1=0x02;
}
void timer2(){
  volatile char*tccr2a=0xB0;
  volatile char*tccr2b=0xB1;
  volatile char*tcnt2=0xB2;
  volatile char*ocr2a=0xB3;
  volatile char*timsk2=0x70;
  *tccr2a=0x02;
  *tccr2b=0x07;
  *tcnt2=0x00;
  *ocr2a=0xF9;
  *timsk2=0x02;
}
ISR(TIMER1_COMPA_vect){
  volatile char*outa=0x22;
  y++;
  if(y>=1*sec1){
    *outa=*outa^0x01;
    y=0;
  }
}
ISR(TIMER2_COMPA_vect){
  volatile char*outa=0x22;
  x++;
  if(x>=125/sec2){
    *outa=*outa^0x02;
    x=0;
  }
}

