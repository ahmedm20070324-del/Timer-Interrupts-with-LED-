void setup() {
  volatile char*dira=0x21;
  *dira=0x07;
  timer1();
  timer2();
  timer3();
}
long x=0;
long x1=0;
long y=0;
long z=0;
void loop() {

}
void timer1(){
  volatile char*tccr1a=0x80;
  volatile char*tccr1b=0x81;
  volatile char*tcnt1l=0x84;
  volatile char*tcnt1h=0x85;
  volatile char*ocr1al=0x88;
  volatile char*ocr1ah=0x89;
  volatile char*timsk1=0x6F;
  *tccr1a=0x00;
  *tccr1b=0x0D;
  *tcnt1h=0x00;
  *tcnt1l=0x00;
  *ocr1ah=0x3D;
  *ocr1al=0x08;
  *timsk1=0x02;
}
void timer2(){
  volatile char*tccr2a=0xB0;
  volatile char*tccr2b=0xB1;
  volatile char*tcnt2=0xB2;
  volatile char*ocr2a=0xB3;
  volatile char*timsk2=0x70;
  *tccr2a=0x02;
  *tccr2b=0x07;
  *tcnt2=0x00;
  *ocr2a=0xF9;
  *timsk2=0x02;
}
void timer3(){
  volatile char*tccr3a=0x90;
  volatile char*tccr3b=0x91;
  volatile char*tcnt3l=0x94;
  volatile char*tcnt3h=0x95;
  volatile char*ocr3al=0x98;
  volatile char*ocr3ah=0x99;
  volatile char*timsk3=0x71;
  *tccr3a=0x00;
  *tccr3b=0x0D;
  *tcnt3h=0x00;
  *tcnt3l=0x00;
  *ocr3ah=0x3D;
  *ocr3al=0x08;
  *timsk3=0x02;
}
ISR(TIMER1_COMPA_vect){
  volatile char*outa=0x22;
  z++;
  if(z>=4){
    *outa=*outa^0x01;
    z=0;
  }
}
ISR(TIMER2_COMPA_vect){
  volatile char*outa=0x22;
  x++;
  if(x>=125){
    x1++;
    x=0;
    if(x1>=2){
      *outa=*outa^0x02;
      x1=0;
    }
  }
}
ISR(TIMER3_COMPA_vect){
  volatile char*outa=0x22;
  y++;
  if(y>=4){
    *outa=*outa^0x04;
    y=0;
  }
}